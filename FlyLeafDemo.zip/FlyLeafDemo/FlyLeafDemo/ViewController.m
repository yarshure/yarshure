//
//  ViewController.m
//  FlyLeafDemo
//
//  Created by 孔祥波 on 12-12-17.
//  Copyright (c) 2012年 Kong XiangBo. All rights reserved.
//

#import "ViewController.h"
#import <QuartzCore/CAAnimation.h>
#define length 1024

static inline double radians(double degrees) { return degrees * M_PI / 180; }
static inline double adians(double degrees) { return degrees *  180/M_PI ;}
@interface ViewController ()

@property (nonatomic,strong) NSMutableArray *leafs;
@end

@implementation ViewController

- (void)viewDidLoad
{
    _leafs=[[NSMutableArray alloc] initWithCapacity:4];
    [super viewDidLoad];
    for (int i=0; i<4;i++ ) {
      
        UIImage *image=[UIImage imageNamed:[NSString stringWithFormat: @"leaf%d",i+1]];
        UIImageView *imageView=[[UIImageView alloc] initWithImage:image];
        imageView.center=CGPointMake(image.size.width*i+170+length, 391);
        [self.view addSubview:imageView];
        [_leafs addObject:imageView];
    }
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)shouldAutorotate
{
    //UIDeviceOrientation orientation =[[UIDevice currentDevice] orientation];
    
    return YES;
}
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskLandscape;
}
- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    return UIInterfaceOrientationLandscapeLeft|UIInterfaceOrientationLandscapeRight;
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
    return (toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft || toInterfaceOrientation ==UIInterfaceOrientationLandscapeRight);
    
}
- (IBAction)doAnimation:(id)sender {
    int i;
	
	for (i=0 ; i< [_leafs count] ;i++) {
		
		UIView *tmpBarItem = [_leafs objectAtIndex:i ];
		[tmpBarItem.layer addAnimation:[self leafsAnimation:CGPointMake(tmpBarItem.center.x,tmpBarItem.center.y-tmpBarItem.frame.size.height/2)
                                                  beginTime:0
                                              Animationname:[NSString stringWithFormat:@"%d",i ]] forKey:@"position"];
        tmpBarItem.layer.anchorPoint= CGPointMake(0.5, 0);
		tmpBarItem.center = CGPointMake(tmpBarItem.center.x-length,tmpBarItem.center.y-tmpBarItem.frame.size.height/2);
		
        
	}
}

-(CAAnimation*)leafsAnimation:(CGPoint)fromPoint beginTime:(CGFloat)abeginTime Animationname:(NSString *)name
{
    CAKeyframeAnimation *move0 = [CAKeyframeAnimation animationWithKeyPath:@"position"];
	CGMutablePathRef thePath0 = CGPathCreateMutable();
	CGPathMoveToPoint(thePath0, NULL, fromPoint.x, fromPoint.y);
	CGPathAddLineToPoint(thePath0, NULL, fromPoint.x-length, fromPoint.y);
    float t1=1.2;
    float t2= 1.0;
	move0.duration=t1;
	move0.path = thePath0;
	CGPathRelease(thePath0);
	
    
    //CABasicAnimation *move = [CABasicAnimation animationWithKeyPath:@"transform"];
	
    
	CAKeyframeAnimation *move = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
	move.removedOnCompletion = YES;
    move.beginTime = t1;
	move.duration = t2;
	
    
    
    
	move.values = [NSArray arrayWithObjects:
                   [NSValue valueWithCATransform3D:CATransform3DMakeAffineTransform(CGAffineTransformMakeRotation(radians(-10)))],
				   [NSValue valueWithCATransform3D:CATransform3DMakeAffineTransform(CGAffineTransformMakeRotation(radians(20)))],
				   [NSValue valueWithCATransform3D:CATransform3DMakeAffineTransform(CGAffineTransformMakeRotation(radians(-(20/2+5))))],
				   [NSValue valueWithCATransform3D:CATransform3DMakeAffineTransform(CGAffineTransformMakeRotation(radians(10)))],
				   [NSValue valueWithCATransform3D:CATransform3DMakeAffineTransform(CGAffineTransformMakeRotation(radians(-(10/2+2.5))))],
				   [NSValue valueWithCATransform3D:CATransform3DMakeAffineTransform(CGAffineTransformMakeRotation(radians(5)))],
                   [NSValue valueWithCATransform3D:CATransform3DMakeAffineTransform(CGAffineTransformMakeRotation(radians(0)))],nil];
	move.keyTimes = [NSArray arrayWithObjects:
					 [NSNumber numberWithFloat:0.0],
					 [NSNumber numberWithFloat:0.2],
					 [NSNumber numberWithFloat:0.4],
					 [NSNumber numberWithFloat:0.6],
                     [NSNumber numberWithFloat:0.8],
					 [NSNumber numberWithFloat:1],nil];
    
	CAAnimationGroup *group = [CAAnimationGroup animation];
	group.duration = t1+t2;
	group.delegate = self;
	[group setValue:name forKey:@"name"];
	//move.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
	group.animations = [NSArray arrayWithObjects:move0,move,nil];
	return group;
}

- (void)animationDidStop:(CAAnimation *)theAnimation finished:(BOOL)flag {
	NSLog(@"%@",[theAnimation valueForKey:@"name"]);
}

@end
