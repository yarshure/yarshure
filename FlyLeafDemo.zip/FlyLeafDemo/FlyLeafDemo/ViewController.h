//
//  ViewController.h
//  FlyLeafDemo
//
//  Created by 孔祥波 on 12-12-17.
//  Copyright (c) 2012年 Kong XiangBo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)doAnimation:(id)sender;

@end
