//
//  main.m
//  FlyLeafDemo
//
//  Created by 孔祥波 on 12-12-17.
//  Copyright (c) 2012年 Kong XiangBo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
